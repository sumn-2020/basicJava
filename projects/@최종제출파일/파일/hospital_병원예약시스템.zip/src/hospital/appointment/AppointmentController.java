package hospital.appointment;

import java.sql.Date;
import java.util.List;

import hospital.HospitalApplication;
import hospital.join.DoctorVO;
import hospital.join.PatientVO;

public class AppointmentController {
	private static AppointmentController instance = new AppointmentController();
	public static AppointmentController getInstance() {
		return instance;
	}
	private AppointmentController() {}
	
	private AppointmentService service = AppointmentService.getInstance();
	private AppointmentVO session = HospitalApplication.getSession5();
	private PatientVO session1 = HospitalApplication.getSession();
	private DoctorVO session2 = HospitalApplication.getSession2();
	
	public AppointmentController(AppointmentService service) {
		this.service = service;
	}
	
	//예약조회(세부조회)
	public List<AppointmentVO> findAppointment() {
		return service.findAppointment(session1.getpatCode());
	}
	
	public int insertAppointment(String docCode, String resMemo) {
		return service.insertAppointment(session1.getpatCode(),docCode,resMemo);
	}
	
	public int deleteAppointment(String resCode) {
		return service.deleteAppointment(resCode);
	}
	
	public int updateAppointment(String resCode, String resDate, String docCode) {
		return service.updateAppointment(resCode , resDate, docCode, session1.getpatCode());
	}
	
	public List<AppointmentVO> selectDocAppointment() {
		return service.selectDocAppointment(session2.getDocCode());
	}
	
	public List<DoctorVO> findAllDocotor(){
		return service.findAllDoctor();
	}
}
