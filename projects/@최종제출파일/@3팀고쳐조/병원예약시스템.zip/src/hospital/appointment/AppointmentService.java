package hospital.appointment;

import java.sql.Date;
import java.util.List;

import hospital.join.DoctorVO;

public class AppointmentService {
	private static AppointmentService instance = new AppointmentService();
	public static AppointmentService getInstance() {
		return instance;
	}
	private AppointmentService() {}
	
	private AppointmentDAO dao = AppointmentDAO.getInstance();
	
	
	public List<AppointmentVO> findAppointment(String patCode) {
		return dao.findAppointment(patCode);
	}
	
	public int insertAppointment(String patCode,String docCode, String resMemo) {
		return dao.insertAppointment(patCode,docCode,resMemo);
	}
	
	public int deleteAppointment(String patCode) {
		return dao.deleteAppointment(patCode);
	}
	
	public int updateAppointment(String resCode, String resDate, String docCode, String patCode) {
		return dao.updateAppointment(Date.valueOf(resDate), docCode, resCode, patCode);
	}
	
	public List<AppointmentVO> selectDocAppointment(String docCode) {
		return dao.selectDocAppointment(docCode);
	}
	
	public List<DoctorVO> findAllDoctor(){
		return dao.findAllDoctor();
	}
}
